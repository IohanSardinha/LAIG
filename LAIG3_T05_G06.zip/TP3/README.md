# LAIG 2020/2021 - TP3

## Group: T05G04

| Name             | Number    | E-Mail             |
| ---------------- | --------- | ------------------ |
| Iohan Soares     | 201801011 |up201801011@fe.up.pt|
| Muriel Pinho     | 201700132 |up201700132@fe.up.pt|

----
## Project information

**Versão**: tp3-v1.0

**Data**: 03/01/2021

#### Funcionalidades: 

* Sequencia de movimentos. - Apertando espaço
* Animação no movimento das peças e da camera.
* Menu interativo.
* Alteração de dificuldade, modo e cena durante a execução, sem perde progresso.
* Movimentos do game salvo.
* Jogo controlodo pelo orchestrator.
* Undo e Animator implementados mas deixados de fora por causa de um pequenos bugs.


#### Cena:

Foram criadas duas cenas, utilizando arquivos .obj e geometrias criadas por nós.

* A primeira consiste de um lago contendo:
    - Flores.
    - Pedras.
    - Relogio com Placar e indicador de turno.
    - Montanhas.
    - Lago.
    - Campo de grama.
    - Tabuleiro transparente.
    - Troncos de arvores caidas.
    - Grama alta.

* A segunda cena consiste de uma montanha contendo:
    - Arvores.
    - Tabuleiro.
    - Relogio com Placar e indicador de turno.
    - Montanhas.
    - Lago.
    - Campo de grama.




* Caminhos para os arquivos
    - [Diretorio Cenas](scenes)
    - [Montanha](scenes/mountain.xml)
    - [Montanha](scenes/lake.xml)
    - [Imagens da cena](scenes/images)
    - [Objetos da cena](scenes/models)